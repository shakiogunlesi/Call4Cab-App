package com.example.user.callforcab;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int km = 0;
    int money;
    public void order (View view){

        RadioGroup radio1 = (RadioGroup) findViewById(R.id.radio_group_2);
        int to = radio1.getCheckedRadioButtonId();

        if (to == R.id.radio_4){
            km += 10;
        }
        else if(to == R.id.radio_5){

            km += 20;

        }
        else if (to == R.id.radio_6){
            km += 30;
        }


        RadioGroup radio2 = (RadioGroup) findViewById(R.id.radio_group_3);
        int price = radio2.getCheckedRadioButtonId();

        if (price == R.id.radio_7){
            money = km * 200;
        }
        else if(price == R.id.radio_8){

            money = km * 500;

        }

        EditText name = (EditText) findViewById(R.id.name);
        String mee = name.getText().toString();

        EditText phone = (EditText) findViewById(R.id.phone);
        String phoneno = phone.getText().toString();


        String own = "Name: " + mee;
        own += "\nPhone Number: " + phoneno;
        own += "\nPrice " + money;
        own +=   "\nThank You";

        Intent mail = new Intent (Intent.ACTION_SENDTO);
        mail.setData(Uri.parse("mailto:"));
        mail.putExtra(Intent.EXTRA_EMAIL, "shaki_ogunlesi@outlook.com");
        mail.putExtra(Intent.EXTRA_SUBJECT, "Cab Call for " + mee);
        mail.putExtra(Intent.EXTRA_TEXT, own);
        if (mail.resolveActivity(getPackageManager()) != null){
            startActivity(mail);
        }







    }




}